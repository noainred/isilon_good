"""글로벌 통합 포탈(HQ) — 여러 데이터센터(엣지)를 한 화면에서 조망한다.

각 엣지는 `serve` 로 로컬 스토리지를 스캔하고 `/api/dbexport`(토큰 보호)로
완료된 per-run DB + 노드 요약(meta.json)을 tar.gz 로 제공한다. 포탈은:
  - 노드(엣지) 목록을 portal_nodes.json 에 보관(웹에서 추가/수정/삭제)
  - 주기적으로 각 노드를 폴링(연결·요약)하고 완료 DB 를 replicas/<id>/ 로 복제
  - 전체/지역/노드별 사용량 롤업을 글로벌 대시보드로 제공

표준 라이브러리만 사용한다(폐쇄망 호환). 엣지 한 곳만 호출하므로 운영이 단순하다.
"""

from typing import Optional

import io
import json
import os
import re
import secrets
import shlex
import shutil
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

from . import __version__
from . import db as dbmod
from . import manager as mgrmod
from . import auth as authmod
from . import audit as auditmod
from . import settings as setmod
from . import upgrade as upgrademod
from .server import ThreadingHTTPServer, browse_dir  # 3.6 폴백 포함 재사용


HERE = os.path.dirname(os.path.abspath(__file__))
PORTAL_HTML = os.path.join(HERE, "portal.html")

# 폴링(연결+요약)은 자주, 복제(완료 DB 내려받기)는 노드별 주기마다.
POLL_EVERY = 15.0       # 초
SCHED_TICK = 5.0        # 초
FAR_FUTURE = 9999999999  # since 가 미래면 meta.json 만 받아 가볍게 연결/요약 확인


# --------------------------------------------------------------- 노드 레지스트리
def nodes_path(data_dir: str) -> str:
    return os.path.join(data_dir, "portal_nodes.json")


def portal_settings_path(data_dir: str) -> str:
    return os.path.join(data_dir, "portal_settings.json")


def ping_history_path(data_dir: str) -> str:
    return os.path.join(data_dir, "ping_history.db")


def sanitize_node(raw: dict) -> Optional[dict]:
    """노드 1건을 보정한다(필수: id, url). 잘못되면 None."""
    if not isinstance(raw, dict):
        return None
    nid = str(raw.get("id") or "").strip()
    url = str(raw.get("url") or "").strip().rstrip("/")
    if not nid or not url:
        return None
    if not re.match(r"^https?://", url):
        url = "http://" + url
    try:
        interval = max(1, int(raw.get("interval_minutes", 30)))
    except (TypeError, ValueError):
        interval = 30
    mode = raw.get("mode", "both")
    if mode not in ("both", "poll", "replicate"):
        mode = "both"

    def _f(v):
        try:
            return float(v or 0)
        except (TypeError, ValueError):
            return 0.0

    # 복제 주기: 예약 스캔과 같은 '시작 + 반복주기' 모델(분/시간/일/주/개월).
    # 구버전(interval_minutes 만 있던) 노드는 unit=minute, every=interval_minutes 로 호환.
    unit = raw.get("unit")
    if unit not in ("minute", "hour", "day", "week", "month"):
        unit = "minute"
    if raw.get("every") is not None:
        try:
            every = max(1, int(raw.get("every")))
        except (TypeError, ValueError):
            every = interval if unit == "minute" else 1
    else:
        every = interval if unit == "minute" else 1
    weekdays = sorted({d for d in (raw.get("weekdays") or [])
                       if isinstance(d, int) and 0 <= d <= 6})
    hh, mm = setmod.parse_at(raw.get("at"))
    anchor = _f(raw.get("anchor")) or time.time()

    def _i(key, lo, hi, dflt):
        try:
            return max(lo, min(hi, int(raw.get(key, dflt))))
        except (TypeError, ValueError):
            return dflt

    return {
        "id": nid,
        "region": str(raw.get("region") or "").strip(),
        "url": url,
        "token": str(raw.get("token") or ""),
        # 경로 별칭: 이 노드의 로컬 마운트 접두어 ↔ 공통 논리 접두어
        # 예) alias_local=/mnt/isilon/data, alias_logical=/data
        "alias_local": str(raw.get("alias_local") or "").strip().rstrip("/"),
        "alias_logical": str(raw.get("alias_logical") or "").strip().rstrip("/"),
        "interval_minutes": interval,
        "unit": unit,
        "every": every,
        "at": "%02d:%02d" % (hh, mm),
        "weekdays": weekdays,
        "start_month": _i("start_month", 1, 12, 1),
        "start_day": _i("start_day", 1, 31, 1),
        "anchor": anchor,
        "mode": mode,
        "enabled": bool(raw.get("enabled", True)),
        "last_poll": _f(raw.get("last_poll")),
        "last_sync": _f(raw.get("last_sync")),
        "last_status": str(raw.get("last_status") or "unknown"),
        "last_error": str(raw.get("last_error") or ""),
    }


def load_nodes(data_dir: str) -> list:
    try:
        with open(nodes_path(data_dir), "r", encoding="utf-8") as fh:
            raw = json.load(fh)
    except (OSError, ValueError):
        return []
    out = []
    for it in (raw.get("nodes") if isinstance(raw, dict) else raw) or []:
        n = sanitize_node(it)
        if n:
            out.append(n)
    return out


def save_nodes(data_dir: str, nodes: list) -> None:
    """노드 레지스트리를 원자적으로 저장한다.

    병렬 복제 스레드가 동시에 저장해도 충돌하지 않도록 스레드마다 '고유 임시파일'을 쓰고
    (os.replace 로 원자 교체), 노드 스냅샷을 떠 직렬화 중 변경 영향을 피한다.
    """
    os.makedirs(data_dir, exist_ok=True)
    path = nodes_path(data_dir)
    payload = json.dumps({"nodes": [dict(n) for n in nodes]},
                         ensure_ascii=False, indent=2)
    fd, tmp = tempfile.mkstemp(prefix=".portal_nodes-", suffix=".tmp", dir=data_dir)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _public_node(n: dict, cache: dict) -> dict:
    """화면용 노드(토큰 마스킹 + 실시간 캐시 상태 병합)."""
    c = cache.get(n["id"], {})
    ov = c.get("overall") or {}
    out = dict(n)
    out["token"] = ""
    out["token_set"] = bool(n.get("token"))
    out["online"] = bool(c.get("online"))
    out["version"] = c.get("version")
    out["hostname"] = c.get("hostname")
    out["error"] = n.get("last_error") or c.get("error") or ""
    out["active_scans"] = int(ov.get("active_scans") or 0)   # 지금 스캔 중인 개수
    out["scanning"] = out["active_scans"] > 0
    out["used_bytes"] = int(ov.get("total_scanned_bytes") or 0)
    return out


# ------------------------------------------------------------------ 네트워크
def _http_get(url: str, token: Optional[str] = None, timeout: float = 8.0):
    req = urllib.request.Request(url)
    if token:
        req.add_header("X-Auth-Token", token)
    return urllib.request.urlopen(req, timeout=timeout)


def _probe_meta(url: str, token: Optional[str], timeout: float = 8.0) -> dict:
    """엣지의 /api/dbexport?since=먼미래 로 meta.json 만 받아(가볍게) 요약을 돌려준다.

    연결 확인 + 토큰 검증 + 노드 요약(overall)을 한 번에 처리한다.
    """
    u = url.rstrip("/") + "/api/dbexport?since=%d" % FAR_FUTURE
    resp = _http_get(u, token, timeout=timeout)
    data = resp.read()
    tf = tarfile.open(fileobj=io.BytesIO(data), mode="r:gz")
    try:
        f = tf.extractfile("meta.json")
        return json.loads(f.read().decode("utf-8"))
    finally:
        tf.close()


# ------------------------------------------------------------ 원격 자동 구성
def agent_bundle_bytes() -> bytes:
    """엣지에 배포할 isilon_usage 패키지(.py/.html)를 tar.gz 로 묶는다.

    엣지가 HQ 포탈에서 코드를 직접 받아 설치할 수 있게 한다(폐쇄망에서도 인터넷
    없이). 포탈이 실행 중인 바로 그 패키지를 그대로 내려준다.
    """
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        for name in sorted(os.listdir(HERE)):
            if name.endswith(".py") or name.endswith(".html"):
                tf.add(os.path.join(HERE, name), arcname="isilon_usage/" + name)
    return buf.getvalue()


def build_provision_script(*, host, port, token, path, hq_base, install="systemd",
                           data_dir="/data/isilon_edge_data",
                           edge_dir="/opt/isilon_edge") -> str:
    """엣지에서 복붙 실행할 자동 구성 스크립트(bash)를 만든다.

    HQ 포탈에서 코드를 받아(agent-bundle) 배치하고, api_token·mount-base 와 함께
    serve 를 기동한다(systemd 또는 nohup). 값은 shell 주입을 막기 위해 따옴표 처리.
    """
    q = shlex.quote
    hq = (hq_base or "http://<HQ-IP>:8800").rstrip("/")
    head = (
        "#!/usr/bin/env bash\n"
        "set -euo pipefail\n"
        "# === isilon_usage 엣지 자동 구성 (HQ 포탈 생성) ===\n"
        "EDGE_DIR=%s\nDATA=%s\nMOUNT=%s\nPORT=%d\nTOKEN=%s\nHQ=%s\n\n"
        'echo "[1/3] HQ 포탈에서 코드 받기 (인터넷 불필요)"\n'
        'sudo mkdir -p "$EDGE_DIR" "$DATA"\n'
        'curl -fsSL "$HQ/api/portal/agent-bundle" | sudo tar -xz -C "$EDGE_DIR"\n'
        '(cd "$EDGE_DIR" && python3 -m isilon_usage --version)\n'
    ) % (q(edge_dir), q(data_dir), q(path), int(port), q(token), q(hq))
    if install == "nohup":
        tail = (
            '\necho "[2/3] nohup 으로 기동 (포트 $PORT)"\n'
            'cd "$EDGE_DIR"\n'
            'nohup python3 -m isilon_usage serve --data-dir "$DATA" --mount-base "$MOUNT" \\\n'
            '    --host 0.0.0.0 --port "$PORT" --api-token "$TOKEN" \\\n'
            '    > /var/log/isilon_usage.log 2>&1 &\n'
            'echo "[3/3] 완료 — http://%s:%d/  (HQ 포탈이 자동 폴링)"\n'
        ) % (host, int(port))
    else:
        tail = (
            '\necho "[2/3] systemd 서비스 설치/기동 (포트 $PORT)"\n'
            "sudo tee /etc/systemd/system/isilon-edge.service >/dev/null <<UNIT\n"
            "[Unit]\n"
            "Description=Isilon Edge - 디렉터리 사용량 스캐너\n"
            "After=network-online.target remote-fs.target\n"
            "Wants=network-online.target\n"
            "[Service]\n"
            "Type=simple\n"
            "User=root\n"
            "WorkingDirectory=$EDGE_DIR\n"
            "ExecStart=/usr/bin/python3 -m isilon_usage serve --data-dir $DATA "
            "--mount-base $MOUNT --host 0.0.0.0 --port $PORT --api-token $TOKEN\n"
            "Restart=on-failure\n"
            "RestartSec=5\n"
            "[Install]\n"
            "WantedBy=multi-user.target\n"
            "UNIT\n"
            "sudo systemctl daemon-reload\n"
            "sudo systemctl enable --now isilon-edge\n"
            'echo "[3/3] 완료 — http://%s:%d/  ·  journalctl -u isilon-edge -f"\n'
        ) % (host, int(port))
    return head + tail


def build_upgrade_script(*, hq_base, edge_dir="/opt/isilon_edge",
                         service="isilon-edge") -> str:
    """등록된 엣지를 HQ 의 최신 코드로 올리는 bash 업그레이드 스크립트를 만든다.

    HQ 포탈에서 agent-bundle(현재 실행 중 코드)을 받아 엣지 코드 디렉터리에 덮어쓰고
    서비스를 재시작한다. 값은 shell 주입을 막기 위해 따옴표 처리한다.
    """
    q = shlex.quote
    hq = (hq_base or "http://<HQ-IP>:8800").rstrip("/")
    return (
        "#!/usr/bin/env bash\n"
        "set -euo pipefail\n"
        "# === isilon_usage 엣지 원격 업그레이드 (HQ 포탈 생성) ===\n"
        "EDGE_DIR=%s\nHQ=%s\nSERVICE=%s\n\n"
        "# 서비스의 실제 코드 디렉터리를 systemd 에서 자동 감지(없으면 EDGE_DIR)\n"
        'WD=$(systemctl show -p WorkingDirectory --value "$SERVICE" 2>/dev/null || true)\n'
        'TARGET="${WD:-$EDGE_DIR}"; [ -z "$TARGET" ] && TARGET="$EDGE_DIR"\n'
        'OLDV=$(cd "$TARGET" 2>/dev/null && python3 -m isilon_usage --version 2>/dev/null || echo "?")\n'
        'echo "[1/3] HQ 에서 최신 코드 받기 -> $TARGET (현재 $OLDV)"\n'
        'sudo mkdir -p "$TARGET"\n'
        'curl -fsSL "$HQ/api/portal/agent-bundle" | sudo tar -xz -C "$TARGET"\n'
        'NEWV=$(cd "$TARGET" && python3 -m isilon_usage --version 2>/dev/null || echo "?")\n'
        'echo "  -> 새 코드: $NEWV"\n'
        'echo "[2/3] 서비스 재시작: $SERVICE"\n'
        'if systemctl list-unit-files 2>/dev/null | grep -q "^${SERVICE}\\.service"; then\n'
        '  sudo systemctl restart "$SERVICE"\n'
        '  echo "  -> systemctl restart $SERVICE 완료"\n'
        "else\n"
        '  echo "  WARN: systemd 유닛 ${SERVICE} 없음 - 코드는 $TARGET 에 갱신됨, 서비스를 수동 재시작하세요"\n'
        "fi\n"
        'echo "[3/3] 업그레이드 $OLDV -> $NEWV (대상 $TARGET, 서비스 $SERVICE)"\n'
    ) % (q(edge_dir), q(hq), q(service))


# ------------------------------------------------------------------ 컨트롤러
class PortalController:
    def __init__(self, data_dir: str) -> None:
        self.data_dir = os.path.abspath(data_dir)
        self.replicas_dir = os.path.join(self.data_dir, "replicas")
        os.makedirs(self.replicas_dir, exist_ok=True)
        self.nodes = load_nodes(self.data_dir)
        self.settings = self._load_settings()
        self._auth = authmod.AuthGuard(lambda: self.settings.get("op_password"))
        self._last_upgrade_check = 0.0
        self._init_ping_db()
        self._cache = {}          # id -> {online, ts, version, hostname, overall, error}
        self._inflight = set()
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread = None
        self.poll_every = POLL_EVERY
        self.tick = SCHED_TICK
        self._upg_state = {"log": [], "installing": False, "available": False,
                           "latest": None, "last_check": None}   # 인터넷 자동 업그레이드 상태

    # --- 인증(작업 보호: 보기는 자유, 변경은 로그인) ---
    def _load_settings(self) -> dict:
        out = {"op_password": "", "op_password_encrypted": False,
               "upgrade_watch_dir": "", "upgrade_check_secs": 60,
               "upgrade_source": "off", "upgrade_url": "", "upgrade_auto": False}
        try:
            with open(portal_settings_path(self.data_dir), encoding="utf-8") as fh:
                s = json.load(fh)
            if isinstance(s, dict):
                out["op_password"] = str(s.get("op_password") or "")
                out["op_password_encrypted"] = bool(s.get("op_password_encrypted", False))
                out["upgrade_watch_dir"] = str(s.get("upgrade_watch_dir") or "").strip()
                try:
                    out["upgrade_check_secs"] = max(10, int(s.get("upgrade_check_secs", 60) or 60))
                except (TypeError, ValueError):
                    pass
                _src = str(s.get("upgrade_source") or "off").strip().lower()
                out["upgrade_source"] = _src if _src in ("off", "github") else "off"
                out["upgrade_url"] = str(s.get("upgrade_url") or "").strip()
                out["upgrade_auto"] = bool(s.get("upgrade_auto"))
        except (OSError, ValueError):
            pass
        return out

    def _save_settings(self) -> None:
        os.makedirs(self.data_dir, exist_ok=True)
        path = portal_settings_path(self.data_dir)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.settings, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

    def auth_required(self) -> bool:
        return self._auth.required()

    def auth_status(self) -> dict:
        return {"ok": True, "op_required": self._auth.required(),
                "encrypted": bool(self.settings.get("op_password_encrypted"))}

    def login(self, password: str) -> dict:
        return self._auth.login(password)

    def token_valid(self, token) -> bool:
        return self._auth.token_valid(token)

    def set_password(self, new_password: str, encrypt: bool) -> dict:
        """비밀번호 설정/변경/해제. 호출 측(핸들러)에서 인증을 확인한다."""
        pw = str(new_password or "")
        enc = bool(encrypt)
        self.settings["op_password"] = authmod.store_password(pw, encrypt=enc) if pw else ""
        self.settings["op_password_encrypted"] = enc if pw else False
        self._save_settings()
        return {"ok": True, "op_required": bool(self.settings["op_password"]),
                "encrypted": self.settings["op_password_encrypted"]}

    # --- 자동 업그레이드 ---
    def set_upgrade_watch(self, watch_dir: str, check_secs=None) -> dict:
        self.settings["upgrade_watch_dir"] = str(watch_dir or "").strip()
        if check_secs is not None:
            try:
                self.settings["upgrade_check_secs"] = max(10, int(check_secs))
            except (TypeError, ValueError):
                pass
        self._save_settings()
        return {"ok": True, "upgrade_watch_dir": self.settings["upgrade_watch_dir"],
                "upgrade_check_secs": self.settings["upgrade_check_secs"]}

    def upgrade_config(self) -> dict:
        return {"ok": True, "upgrade_watch_dir": self.settings.get("upgrade_watch_dir", ""),
                "upgrade_check_secs": self.settings.get("upgrade_check_secs", 60),
                "hq_version": __version__}

    def push_upgrade_all(self) -> dict:
        """등록된 모든 엣지에 현재(=새) 코드 번들을 푸시한다(엣지 api_token 인증)."""
        data = agent_bundle_bytes()
        results = []
        for n in list(self.nodes):
            url = n["url"].rstrip("/") + "/api/upgrade"
            try:
                req = urllib.request.Request(url, data=data, method="POST")
                req.add_header("Content-Type", "application/gzip")
                if n.get("token"):
                    req.add_header("X-Auth-Token", n["token"])
                resp = urllib.request.urlopen(req, timeout=120)
                j = json.loads(resp.read().decode("utf-8"))
                results.append({"id": n["id"], "ok": bool(j.get("ok")),
                                "version": j.get("version"), "reason": j.get("reason")})
            except urllib.error.HTTPError as e:  # type: ignore[attr-defined]
                reason = ("구버전 엣지(<1.41.0): 푸시 미지원 — SSH 업그레이드로 부트스트랩 필요"
                          if e.code == 404 else
                          "거부됨 — 엣지에 api_token 설정 필요" if e.code == 403 else
                          "HTTP %d" % e.code)
                results.append({"id": n["id"], "ok": False, "reason": reason})
            except Exception as e:  # noqa: BLE001
                results.append({"id": n["id"], "ok": False, "reason": str(e)})
        return {"ok": True, "hq_version": __version__, "results": results}

    def push_upgrade_all_ssh(self, raw: dict) -> dict:
        """[부트스트랩] 등록된 모든 엣지에 SSH 로 접속해 업그레이드 스크립트를 실행한다.

        엣지가 구버전(/api/upgrade 없음)이어도 동작한다 — 스크립트가 HQ 에서 새 코드를 받아
        교체·재시작한다. ssh/sshpass 필요(보통 공용 계정/비번). 비번은 1회성으로만 쓴다.
        """
        from concurrent.futures import ThreadPoolExecutor
        hq_base = (raw.get("hq_base") or "").strip()
        edge_dir = (raw.get("edge_dir") or "/opt/isilon_edge").strip()
        service = (raw.get("service") or "isilon-edge").strip()
        script = build_upgrade_script(hq_base=hq_base, edge_dir=edge_dir, service=service)
        user = (raw.get("ssh_user") or "root").strip()
        password = raw.get("ssh_password") or ""
        port = raw.get("ssh_port") or 22

        def _one(n):
            host = urlparse(n["url"]).hostname or ""
            if not host:
                return {"id": n["id"], "ok": False,
                        "reason": "노드 URL 에서 host 를 못 읽음(노드 설정의 url 확인)"}
            res = self._ssh_run({"host": host, "ssh_user": user,
                                 "ssh_password": password, "ssh_port": port}, script)
            if res.get("ok"):
                return {"id": n["id"], "ok": True}
            rc = res.get("returncode")
            reason = res.get("reason") or (
                "SSH 연결/인증 실패" if rc == 255 else
                "업그레이드 스크립트 실패" if rc is not None else "실패")
            return {"id": n["id"], "ok": False, "reason": reason,
                    "detail": (res.get("output") or "").strip(), "returncode": rc}

        nodes = list(self.nodes)
        if nodes:
            with ThreadPoolExecutor(max_workers=min(8, len(nodes))) as ex:
                results = list(ex.map(_one, nodes))
        else:
            results = []
        return {"ok": True, "hq_version": __version__, "results": results}

    def _check_self_upgrade(self) -> None:
        """새 버전을 자가 적용 → 엣지 푸시 → 재시작 — ① 감시 폴더 ② 인터넷(GitHub)."""
        with self._lock:
            if self._inflight:       # 동기화/복제 중이면 미룬다(중단 방지)
                return
        code_dir = upgrademod.code_dir_of(__file__)
        # ① 로컬 감시 폴더
        wd = (self.settings.get("upgrade_watch_dir") or "").strip()
        if wd:
            found = upgrademod.find_newer_archive(wd, __version__)
            if found:
                res = upgrademod.upgrade_from_archive(found[0], code_dir, __version__)
                if res.get("ok"):
                    self._apply_self_upgrade(res, "감시 폴더")
        # ② 인터넷(GitHub) 소스
        if (self.settings.get("upgrade_source") or "off").strip() == "github":
            info = upgrademod.check_remote(self.settings.get("upgrade_url") or "", __version__)
            self._upg_set_check(info)
            if info.get("available") and bool(self.settings.get("upgrade_auto")):
                self._upg_log("새 버전 %s 발견 — 자동 설치" % info.get("latest"))
                dest = os.path.join(self.data_dir, "upgrades")
                res = upgrademod.upgrade_from_remote(
                    self.settings.get("upgrade_url") or "", code_dir, __version__, dest)
                if res.get("ok"):
                    self._apply_self_upgrade(res, "인터넷")
                else:
                    self._upg_log("자동 설치 실패: %s" % res.get("reason"))

    def _apply_self_upgrade(self, res: dict, how: str) -> None:
        """자가 업그레이드 성공 후: 감사로그 → 엣지 전파 → 재시작(돌아오지 않음)."""
        self._upg_log("%s 자가 업그레이드 %s → %s, 엣지 전파 후 재시작" % (
            how, res.get("from"), res.get("version")))
        auditmod.record(self.data_dir, action="self_upgrade", ok=True,
                        detail="%s -> %s (%s)" % (res.get("from"), res.get("version"), how))
        try:                                  # 새 코드가 디스크에 반영됨 → 엣지에도 푸시
            self.push_upgrade_all()
        except Exception:  # noqa: BLE001
            pass
        upgrademod.restart_process()

    # --- 인터넷 자동 업그레이드 상태/조작(엣지와 동일 + 엣지 전파) ---
    def _upg_log(self, msg: str) -> None:
        with self._lock:
            self._upg_state.setdefault("log", []).append({"t": time.time(), "msg": msg})
            self._upg_state["log"] = self._upg_state["log"][-60:]

    def _upg_set_check(self, info: dict) -> None:
        with self._lock:
            self._upg_state.update({
                "last_check": info.get("checked_at"), "latest": info.get("latest"),
                "available": bool(info.get("available")), "source": info.get("source"),
                "size_bytes": info.get("size_bytes"), "check_error": info.get("error")})

    def upgrade_status(self) -> dict:
        with self._lock:
            st = dict(self._upg_state)
        st["current"] = __version__
        st["source_mode"] = self.settings.get("upgrade_source", "off")
        st["auto"] = bool(self.settings.get("upgrade_auto"))
        st["url"] = self.settings.get("upgrade_url") or upgrademod.DEFAULT_UPGRADE_BASE
        st["check_secs"] = self.settings.get("upgrade_check_secs", 60)
        st["node_count"] = len(self.nodes)
        return {"ok": True, **st}

    def upgrade_check(self) -> dict:
        info = upgrademod.check_remote(self.settings.get("upgrade_url") or "", __version__)
        self._upg_set_check(info)
        if info.get("error"):
            self._upg_log("확인 오류: %s" % info["error"])
        else:
            self._upg_log("확인 — 현재 %s · 최신 %s%s" % (
                __version__, info.get("latest"),
                " · 업데이트 가능" if info.get("available") else " · 최신"))
        return {"ok": bool(info.get("ok")), **self.upgrade_status()}

    def upgrade_install(self, *, propagate: bool = True) -> dict:
        with self._lock:
            if self._upg_state.get("installing"):
                return {"ok": False, "error": "이미 설치 중입니다."}
            self._upg_state["installing"] = True
        try:
            code_dir = upgrademod.code_dir_of(__file__)
            dest = os.path.join(self.data_dir, "upgrades")
            self._upg_log("수동 업그레이드 시작…")
            res = upgrademod.upgrade_from_remote(
                self.settings.get("upgrade_url") or "", code_dir, __version__, dest)
        finally:
            with self._lock:
                self._upg_state["installing"] = False
        if not res.get("ok"):
            self._upg_log("설치 실패: %s" % res.get("reason"))
            return {"ok": False, "error": res.get("reason"),
                    "up_to_date": bool(res.get("up_to_date"))}
        propagated = None
        if propagate:
            try:                              # 새 코드를 등록된 엣지에도 전파
                propagated = self.push_upgrade_all().get("results")
            except Exception:  # noqa: BLE001
                pass
        self._upg_log("설치 완료 %s → %s%s — 곧 재시작" % (
            res.get("from"), res.get("version"), " · 엣지 전파" if propagate else ""))
        auditmod.record(self.data_dir, action="self_upgrade_manual", ok=True,
                        detail="-> %s" % res.get("version"))
        threading.Thread(target=lambda: (time.sleep(1.5), upgrademod.restart_process()),
                         daemon=True).start()
        return {"ok": True, "version": res.get("version"), "restarting": True,
                "propagated": propagated}

    def set_upgrade_net(self, source, url, auto, check_secs=None) -> dict:
        src = str(source or "off").strip().lower()
        self.settings["upgrade_source"] = src if src in ("off", "github") else "off"
        self.settings["upgrade_url"] = str(url or "").strip()
        self.settings["upgrade_auto"] = bool(auto)
        if check_secs is not None:
            try:
                self.settings["upgrade_check_secs"] = max(10, int(check_secs))
            except (TypeError, ValueError):
                pass
        self._save_settings()
        return self.upgrade_status()

    # --- 레지스트리 CRUD ---
    def _get(self, nid: str):
        for n in self.nodes:
            if n["id"] == nid:
                return n
        return None

    def _save(self) -> None:
        with self._lock:        # 동시 저장 직렬화(RLock — 호출 측이 이미 잡고 있어도 안전)
            save_nodes(self.data_dir, self.nodes)

    def list_nodes(self) -> dict:
        with self._lock:
            cache = dict(self._cache)
            nodes = [_public_node(n, cache) for n in self.nodes]
        return {"ok": True, "nodes": nodes}

    def upsert_node(self, raw: dict) -> dict:
        n = sanitize_node(raw)
        if not n:
            return {"ok": False, "reason": "id 와 url 은 필수입니다."}
        with self._lock:
            cur = self._get(n["id"])
            if cur is not None:
                # 토큰이 비어 오면 기존 토큰 유지(마스킹)
                if not n["token"]:
                    n["token"] = cur.get("token", "")
                n["last_sync"] = cur.get("last_sync", 0)
                n["last_poll"] = cur.get("last_poll", 0)
                self.nodes = [n if x["id"] == n["id"] else x for x in self.nodes]
            else:
                self.nodes.append(n)
            self._save()
        return {"ok": True, "node": _public_node(n, self._cache)}

    def import_nodes_csv(self, csv_text: str) -> dict:
        """CSV 로 여러 노드를 한 번에 등록(import). 행별 추가/수정/오류를 집계해 반환한다.

        헤더 행이 있으면(컬럼에 url+id 포함) 그 이름으로 매핑하고, 없으면
        id,url,region,token,alias_local,alias_logical 순서로 간주한다. 한글/별칭 헤더도 허용
        (이름→id, 주소/host→url, 지역→region, 토큰→token …). 토큰이 비면 기존 토큰을 유지한다.
        """
        import csv as _csv
        import io as _io
        if not csv_text or not csv_text.strip():
            return {"ok": False, "reason": "CSV 내용이 비어 있습니다."}
        alias = {
            "id": "id", "name": "id", "node": "id", "이름": "id", "노드": "id",
            "url": "url", "address": "url", "host": "url", "주소": "url",
            "region": "region", "지역": "region",
            "token": "token", "토큰": "token", "api_token": "token",
            "alias_local": "alias_local", "local": "alias_local", "로컬": "alias_local",
            "alias_logical": "alias_logical", "logical": "alias_logical", "논리": "alias_logical",
            "mode": "mode",
        }
        try:
            rows = [r for r in _csv.reader(_io.StringIO(csv_text))
                    if any((c or "").strip() for c in r)]
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "reason": "CSV 파싱 오류: %s" % exc}
        if not rows:
            return {"ok": False, "reason": "데이터 행이 없습니다."}
        first = [alias.get((h or "").strip().lower(), (h or "").strip().lower())
                 for h in rows[0]]
        has_header = "url" in first and "id" in first
        if has_header:
            cols, data = first, rows[1:]
        else:
            cols = ["id", "url", "region", "token", "alias_local", "alias_logical"]
            data = rows
        added = updated = 0
        errors = []
        for idx, row in enumerate(data):
            line = idx + (2 if has_header else 1)
            raw = {}
            for j, val in enumerate(row):
                if j < len(cols) and cols[j]:
                    raw[cols[j]] = (val or "").strip()
            if not raw.get("id") or not raw.get("url"):
                errors.append({"line": line, "error": "id/url 누락"})
                continue
            existed = self._get(raw["id"]) is not None
            res = self.upsert_node(raw)
            if res.get("ok"):
                if existed:
                    updated += 1
                else:
                    added += 1
            else:
                errors.append({"line": line, "error": res.get("reason", "등록 실패")})
        return {"ok": True, "added": added, "updated": updated,
                "errors": errors, "total": len(data)}

    def delete_node(self, nid: str) -> dict:
        with self._lock:
            before = len(self.nodes)
            self.nodes = [x for x in self.nodes if x["id"] != nid]
            self._cache.pop(nid, None)
            self._save()
        # 복제본도 정리(베스트 에포트)
        shutil.rmtree(os.path.join(self.replicas_dir, nid), ignore_errors=True)
        return {"ok": before != len(self.nodes)}

    def test_node(self, raw: dict) -> dict:
        """연결 테스트: url(+token) 또는 등록된 id 로 meta 를 받아 본다."""
        nid = str(raw.get("id") or "").strip()
        if nid:
            n = self._get(nid)
            if n is None:
                return {"ok": False, "reason": "등록되지 않은 노드"}
            url, token = n["url"], n.get("token")
        else:
            url = str(raw.get("url") or "").strip()
            token = raw.get("token") or None
            if not url:
                return {"ok": False, "reason": "url 필요"}
            if not re.match(r"^https?://", url):
                url = "http://" + url
        try:
            meta = _probe_meta(url, token, timeout=8.0)
            ov = meta.get("overall") or {}
            return {"ok": True, "version": meta.get("version"),
                    "hostname": meta.get("hostname"),
                    "storages": ov.get("root_count") or 0,
                    "used_bytes": ov.get("total_scanned_bytes") or 0}
        except urllib.error.HTTPError as e:  # type: ignore[attr-defined]
            reason = "인증 실패(토큰 확인)" if e.code == 401 else ("HTTP %d" % e.code)
            return {"ok": False, "reason": reason}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "reason": str(e)}

    # --- 동기화(폴링 + 복제) ---
    def start(self) -> None:
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, name="portal-sync",
                                            daemon=True)
            self._thread.start()
            threading.Thread(target=self._ping_history_loop, name="portal-ping-hist",
                             daemon=True).start()

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                now = time.time()
                secs = int(self.settings.get("upgrade_check_secs", 60) or 60)
                if now - self._last_upgrade_check >= max(10, secs):
                    self._last_upgrade_check = now
                    self._check_self_upgrade()
                for n in list(self.nodes):
                    if not n.get("enabled"):
                        continue
                    nid = n["id"]
                    with self._lock:
                        if nid in self._inflight:
                            continue
                    due_poll = (now - n.get("last_poll", 0)) >= self.poll_every
                    # 복제 시점은 예약 스캔과 동일한 반복주기 모델(schedule_due)로 판정.
                    # last_run 자리에 last_sync 를 넣어 마지막 복제 이후를 기준으로 한다.
                    due_rep = (n.get("mode") in ("both", "replicate") and
                               setmod.schedule_due(dict(n, last_run=n.get("last_sync", 0)), now))
                    if due_poll or due_rep:
                        with self._lock:
                            self._inflight.add(nid)
                        threading.Thread(target=self._sync_one, args=(nid, due_rep),
                                         daemon=True).start()
            except Exception:  # noqa: BLE001 — 스케줄러는 죽지 않는다
                pass
            self._stop.wait(self.tick)

    def sync_now(self, nid: Optional[str] = None) -> dict:
        targets = [nid] if nid else [n["id"] for n in self.nodes if n.get("enabled")]
        for t in targets:
            with self._lock:
                if t in self._inflight:
                    continue
                self._inflight.add(t)
            threading.Thread(target=self._sync_one, args=(t, True), daemon=True).start()
        return {"ok": True, "syncing": targets}

    def _sync_one(self, nid: str, do_rep: bool) -> None:
        try:
            n = self._get(nid)
            if n is None:
                return
            try:
                meta = _probe_meta(n["url"], n.get("token"))
                with self._lock:
                    self._cache[nid] = {
                        "online": True, "ts": time.time(),
                        "version": meta.get("version"), "hostname": meta.get("hostname"),
                        "overall": meta.get("overall") or {},
                        "isilon": meta.get("isilon") or {"configured": False},
                        "storage": meta.get("storage") or [],
                        "error": "",
                    }
                    n["last_poll"] = time.time()
                    n["last_status"] = "online"
                    n["last_error"] = ""
            except Exception as e:  # noqa: BLE001
                with self._lock:
                    c = self._cache.get(nid, {})
                    c.update({"online": False, "error": str(e)})
                    self._cache[nid] = c
                    n["last_poll"] = time.time()
                    n["last_status"] = "offline"
                    n["last_error"] = str(e)
                return  # 오프라인이면 복제 생략
            if do_rep and n.get("mode") in ("both", "replicate"):
                try:
                    newest = self._replicate(n)          # 느린 네트워크 — 락 밖에서
                    with self._lock:
                        n["last_sync"] = max(float(n.get("last_sync", 0)), newest)
                        self._save()
                except Exception as e:  # noqa: BLE001
                    with self._lock:
                        n["last_error"] = "replicate: " + str(e)
        finally:
            with self._lock:
                self._inflight.discard(nid)

    def _replicate(self, n: dict) -> float:
        """완료 DB(증분) + meta.json 을 replicas/<id>/ 로 안전하게 내려받는다."""
        since = int(float(n.get("last_sync", 0) or 0))
        url = n["url"].rstrip("/") + "/api/dbexport?since=%d" % since
        dest = os.path.join(self.replicas_dir, n["id"])
        os.makedirs(os.path.join(dest, "scans"), exist_ok=True)
        fd, tmp = tempfile.mkstemp(suffix=".tar.gz", dir=self.replicas_dir)
        try:
            with os.fdopen(fd, "wb") as f:
                resp = _http_get(url, n.get("token"), timeout=300.0)
                shutil.copyfileobj(resp, f)
            newest = float(n.get("last_sync", 0) or 0)
            tf = tarfile.open(tmp, "r:gz")
            try:
                for m in tf:
                    if not m.isfile():
                        continue
                    name = m.name.lstrip("/")
                    if name == "meta.json":
                        outp = os.path.join(dest, "meta.json")
                    elif (name.startswith("scans/") and name.endswith(".db")
                          and "/" not in name[6:] and ".." not in name):
                        outp = os.path.join(dest, "scans", os.path.basename(name))
                    else:
                        continue  # 경로 탈출 방지: 그 외 멤버는 무시
                    src = tf.extractfile(m)
                    if src is None:
                        continue
                    with open(outp, "wb") as w:
                        shutil.copyfileobj(src, w)
            finally:
                tf.close()
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        # meta 의 완료 시각으로 last_sync 전진
        try:
            with open(os.path.join(dest, "meta.json"), "r", encoding="utf-8") as fh:
                meta = json.load(fh)
            for s in meta.get("scans", []):
                newest = max(newest, float(s.get("finished_at") or 0))
        except (OSError, ValueError):
            pass
        return newest

    # --- 글로벌 롤업 ---
    @staticmethod
    def _fs_capacity(roots_l):
        """노드의 파일시스템 사용/전체 용량. 같은 FS(같은 total)는 한 번만 센다."""
        seen = {}   # fs_total -> 최대 fs_used
        for rt in roots_l:
            ftot = int(rt.get("fs_total_bytes") or 0)
            if ftot <= 0:
                continue
            fused = int(rt.get("fs_used_bytes") or 0)
            if ftot not in seen or fused > seen[ftot]:
                seen[ftot] = fused
        ftot = sum(seen.keys())
        fused = sum(seen.values())
        pct = round(fused / ftot * 100, 1) if ftot else None
        return ftot, fused, max(0, ftot - fused), pct

    @staticmethod
    def _running_scan(roots_l):
        """진행 중(discovering/sizing) 스캔의 시작 시각·경과·단계 요약(없으면 None)."""
        act = [rt for rt in roots_l if rt.get("status") in ("discovering", "sizing")]
        if not act:
            return None
        rep = min(act, key=lambda rt: float(rt.get("started_at") or 9e18))
        started = min((float(rt.get("started_at") or 0) for rt in act
                       if rt.get("started_at")), default=0) or None
        updated = max((float(rt.get("updated_at") or 0) for rt in act), default=0) or None
        return {
            "started_at": started, "updated_at": updated,
            "phase": rep.get("phase"), "root_path": rep.get("root_path"),
            "processed_dirs": int(rep.get("processed_dirs") or 0),
            "total_dirs": int(rep.get("total_dirs") or 0),
            "count": len(act),
        }

    def overview(self) -> dict:
        with self._lock:
            cache = dict(self._cache)
            nodes_snapshot = list(self.nodes)
        regions = {}
        total_used = 0
        total_fs_total = 0
        total_fs_used = 0
        storages = 0
        online = 0
        active = 0
        out_nodes = []
        for n in nodes_snapshot:
            c = cache.get(n["id"], {})
            ov = c.get("overall") or {}
            used = int(ov.get("total_scanned_bytes") or 0)
            st = int(ov.get("root_count") or 0)
            is_on = bool(c.get("online"))
            if is_on:
                online += 1
            active += int(ov.get("active_scans") or 0)
            total_used += used
            storages += st
            reg = n.get("region") or "(미지정)"
            r = regions.setdefault(reg, {"region": reg, "used_bytes": 0, "storages": 0})
            r["used_bytes"] += used
            r["storages"] += st
            roots_l = ov.get("roots") or []
            last_scan = max([0] + [max(rt.get("finished_at") or 0, rt.get("updated_at") or 0)
                                   for rt in roots_l])     # 그 DC 가 마지막으로 스캔한 시각
            fs_total, fs_used, fs_free, fs_pct = self._fs_capacity(roots_l)
            total_fs_total += fs_total
            total_fs_used += fs_used
            out_nodes.append({
                "id": n["id"], "region": n.get("region"), "url": n["url"],
                "enabled": n.get("enabled"), "online": is_on,
                "version": c.get("version"), "hostname": c.get("hostname"),
                "last_poll": n.get("last_poll"), "last_sync": n.get("last_sync"),
                "last_scan_at": last_scan or None,
                "last_error": n.get("last_error") or c.get("error") or "",
                "used_bytes": used, "storages": st,
                "active_scans": int(ov.get("active_scans") or 0),
                "fs_total_bytes": fs_total, "fs_used_bytes": fs_used,
                "fs_free_bytes": fs_free, "fs_used_pct": fs_pct,
                "running": self._running_scan(roots_l),
                "roots": roots_l,
                "isilon": c.get("isilon") or {"configured": False},
                "storage": c.get("storage") or [],
            })
        return {
            "ok": True,
            "version": __version__,
            "totals": {"used_bytes": total_used, "storages": storages,
                       "fs_total_bytes": total_fs_total, "fs_used_bytes": total_fs_used,
                       "nodes_online": online, "nodes_total": len(nodes_snapshot),
                       "active_scans": active},
            "regions": sorted(regions.values(), key=lambda x: -x["used_bytes"]),
            "nodes": out_nodes,
        }

    # --- 노드 응답시간(핑) ---
    def ping_nodes(self) -> dict:
        """각 노드로 HQ→노드 왕복 응답시간(ms)을 측정한다(가벼운 meta 요청 기준).

        포탈이 능동적으로 잴 수 있는 건 'HQ→각 노드' 지연이다. 엣지끼리의
        DC↔DC 메시 핑은 엣지 협조가 필요해 지원하지 않는다(여기선 미측정).
        여러 노드를 동시에(스레드풀) 측정해 전체 소요를 줄인다.
        """
        from concurrent.futures import ThreadPoolExecutor

        with self._lock:
            nodes_snapshot = list(self.nodes)

        def _one(n):
            entry = {"id": n["id"], "region": n.get("region"), "url": n["url"],
                     "online": False, "latency_ms": None, "error": ""}
            if not n.get("enabled"):
                entry["error"] = "비활성"
                return entry
            t0 = time.monotonic()
            try:
                _probe_meta(n["url"], n.get("token"), timeout=8.0)
                entry["online"] = True
                entry["latency_ms"] = round((time.monotonic() - t0) * 1000, 1)
            except urllib.error.HTTPError as e:   # 응답이 왔으니 도달은 됨
                entry["latency_ms"] = round((time.monotonic() - t0) * 1000, 1)
                entry["online"] = True
                entry["error"] = "인증 실패" if e.code == 401 else ("HTTP %d" % e.code)
            except Exception as e:  # noqa: BLE001
                entry["error"] = str(e)
            return entry

        if nodes_snapshot:
            with ThreadPoolExecutor(max_workers=min(16, len(nodes_snapshot))) as ex:
                results = list(ex.map(_one, nodes_snapshot))
        else:
            results = []
        return {"ok": True, "results": results, "checked_at": time.time()}

    # --- 핑 히스토리(서버측 자동 측정 + 최대 1년 저장) ---
    def _init_ping_db(self) -> None:
        try:
            conn = dbmod.connect(ping_history_path(self.data_dir))
            try:
                conn.execute("CREATE TABLE IF NOT EXISTS ping_samples ("
                             "ts INTEGER NOT NULL, node_id TEXT NOT NULL, "
                             "latency_ms REAL, up INTEGER NOT NULL DEFAULT 0)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_ping_ts ON ping_samples(ts)")
                conn.commit()
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            pass

    def _record_ping(self, results: list) -> None:
        rows = [(int(time.time()), r["id"], r.get("latency_ms"), 1 if r.get("online") else 0)
                for r in (results or []) if r.get("id")]
        if not rows:
            return
        try:
            conn = dbmod.connect(ping_history_path(self.data_dir))
            try:
                conn.executemany(
                    "INSERT INTO ping_samples (ts,node_id,latency_ms,up) VALUES (?,?,?,?)", rows)
                conn.commit()
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            pass

    def _prune_ping_history(self) -> None:
        try:
            conn = dbmod.connect(ping_history_path(self.data_dir))
            try:
                conn.execute("DELETE FROM ping_samples WHERE ts < ?",
                             (int(time.time()) - 366 * 86400,))
                conn.commit()
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            pass

    def ping_history(self, range_sec: int, max_points: int = 240) -> dict:
        """기간(초) 동안의 핑 이력을 '노드별' 시계열로 돌려준다(인프라 체크 스타일).

        노드별: region, 평소(중앙값) median, ~max_points 로 다운샘플한 series[{t,ms,up}].
        점 색칠(정상/+20%/+50%)은 화면에서 median 대비로 계산한다.
        """
        import statistics
        range_sec = max(3600, int(range_sec or 86400))
        max_points = max(60, min(1000, int(max_points or 240)))
        bucket = max(60, range_sec // max_points)
        since = int(time.time()) - range_sec
        reg = {x["id"]: x.get("region") for x in list(self.nodes)}
        by_node = {}
        try:
            conn = dbmod.connect(ping_history_path(self.data_dir))
            try:
                cur = conn.execute(
                    "SELECT node_id, (ts/?)*? AS b, AVG(latency_ms), SUM(up), COUNT(*) "
                    "FROM ping_samples WHERE ts>=? GROUP BY node_id, b ORDER BY node_id, b",
                    (bucket, bucket, since))
                for nid, b, avg, up, n in cur.fetchall():
                    by_node.setdefault(nid, []).append(
                        {"t": int(b), "ms": round(avg, 2) if avg is not None else None,
                         "up": int(up) == int(n)})
            finally:
                conn.close()
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "reason": str(e), "nodes": []}
        out = []
        for nid, series in by_node.items():
            vals = [p["ms"] for p in series if p["ms"] is not None]
            med = round(statistics.median(vals), 2) if vals else None
            out.append({"id": nid, "region": reg.get(nid) or "", "median": med,
                        "series": series})
        out.sort(key=lambda x: (x["region"] or "~", x["id"]))
        return {"ok": True, "range": range_sec, "bucket": bucket, "nodes": out}

    def _ping_history_loop(self) -> None:
        last_prune = 0.0
        while not self._stop.is_set():
            try:
                self._record_ping(self.ping_nodes().get("results", []))
                now = time.time()
                if now - last_prune > 3600:        # 1시간마다 1년치 밖 정리
                    self._prune_ping_history()
                    last_prune = now
            except Exception:  # noqa: BLE001
                pass
            self._stop.wait(60)                    # 1분 주기(가장 가는 버킷)

    # --- 원격 스캔 시작(마지막 스캔과 동일 경로) ---
    def node_scan(self, node_id: str) -> dict:
        """온라인·미스캔 노드를 '마지막 스캔과 동일한 경로'로 다시 스캔 시작한다.

        마지막 루트는 캐시(overall.roots)에서 scan_id 가 가장 큰(=최근) 루트의 root_path.
        엣지가 로그인 비밀번호로 보호돼 있으면(op_required) 포탈엔 그 토큰이 없어 시작할 수 없다
        → 사유를 돌려준다(HTTP 200, ok=False). 엔진/백엔드는 엣지 기본 설정을 따른다.
        """
        with self._lock:
            node = next((dict(n) for n in self.nodes if n["id"] == node_id), None)
            cache = dict(self._cache.get(node_id, {})) if node else {}
        if not node:
            return {"ok": False, "reason": "노드를 찾을 수 없습니다."}
        if not node.get("enabled", True):
            return {"ok": False, "reason": "비활성 노드입니다."}
        roots = (cache.get("overall") or {}).get("roots") or []
        if not roots:
            return {"ok": False, "reason": "이 노드에 이전 스캔 기록이 없습니다(먼저 한 번 스캔)."}
        if any(r.get("status") in ("discovering", "sizing") for r in roots):
            return {"ok": False, "reason": "이미 스캔이 진행 중입니다."}
        last = max(roots, key=lambda r: int(r.get("scan_id") or 0))
        path = (last.get("root_path") or "").strip()
        if not path:
            return {"ok": False, "reason": "마지막 스캔 경로를 알 수 없습니다."}
        url = node["url"].rstrip("/") + "/api/scan/start"
        req = urllib.request.Request(
            url, data=json.dumps({"path": path}).encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        if node.get("token"):
            req.add_header("X-Auth-Token", node["token"])
        try:
            resp = urllib.request.urlopen(req, timeout=30)
            j = json.loads(resp.read().decode("utf-8"))
            if j.get("ok"):
                return {"ok": True, "node": node_id, "path": path,
                        "scan_id": j.get("scan_id")}
            return {"ok": False, "path": path,
                    "reason": j.get("reason") or "엣지가 스캔 시작을 거부했습니다."}
        except urllib.error.HTTPError as e:
            reason = (
                "엣지에 로그인 비밀번호가 설정돼 있어 포탈에서 직접 시작할 수 없습니다 — 엣지 화면에서 시작하세요."
                if e.code == 401 else
                "엣지가 웹 스캔을 비활성화했거나 거부했습니다." if e.code == 403 else
                "엣지에 스캔 시작 API가 없습니다(구버전 엣지)." if e.code == 404 else
                "HTTP %d" % e.code)
            return {"ok": False, "reason": reason, "path": path}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "reason": str(e), "path": path}

    # --- 원격 자동 구성 ---
    def provision_plan(self, raw: dict) -> dict:
        """IP/포트/경로 등으로 엣지 설치 스크립트를 생성하고 노드를 자동 등록한다(SSH 없음).

        '엣지에서 복붙 실행할 스크립트'를 돌려주고 그 노드를 포탈에 등록해 둔다
        (엣지가 뜨면 폴링으로 자동 연결). 비밀번호는 다루지 않아 안전하다.
        """
        host = (raw.get("host") or "").strip()
        if not host:
            return {"ok": False, "reason": "host(IP/주소) 필요"}
        try:
            port = int(raw.get("port") or 8765)
        except (TypeError, ValueError):
            port = 8765
        token = (raw.get("token") or "").strip() or secrets.token_hex(16)
        path = (raw.get("path") or "/mnt/hadoop").strip()
        name = ((raw.get("name") or "").strip()
                or re.sub(r"[^A-Za-z0-9_.-]+", "-", host).strip("-") or "edge")
        region = (raw.get("region") or "").strip()
        install = "nohup" if (raw.get("install") == "nohup") else "systemd"
        hq_base = (raw.get("hq_base") or "").strip()
        edge_url = "http://%s:%d" % (host, port)
        script = build_provision_script(host=host, port=port, token=token, path=path,
                                        hq_base=hq_base, install=install)
        node_res = self.upsert_node({
            "id": name, "region": region, "url": edge_url, "token": token,
            "alias_local": path, "alias_logical": path,
            "unit": "minute", "every": 30, "mode": "both", "enabled": True,
        })
        return {"ok": True, "script": script, "token": token, "edge_url": edge_url,
                "install": install, "registered": bool(node_res.get("ok")),
                "node": node_res.get("node")}

    def _ssh_run(self, raw: dict, script: str) -> dict:
        """SSH(키 인증 또는 sshpass 비밀번호)로 원격에 script 를 bash -s 로 실행한다.

        비밀번호는 보관하지 않고 1회성으로만 쓴다. provision/upgrade 의 SSH 실행에 공용.
        """
        import subprocess
        host = (raw.get("host") or "").strip()
        if not host:
            return {"ok": False, "reason": "host(IP/주소) 필요"}
        user = (raw.get("ssh_user") or "root").strip()
        password = raw.get("ssh_password") or ""
        try:
            ssh_port = int(raw.get("ssh_port") or 22)
        except (TypeError, ValueError):
            ssh_port = 22
        ssh = shutil.which("ssh")
        if not ssh:
            return {"ok": False,
                    "reason": "ssh 바이너리가 없습니다 — 생성된 스크립트를 엣지에서 수동 실행하세요."}
        cmd = []
        if password:
            sshpass = shutil.which("sshpass")
            if not sshpass:
                return {"ok": False,
                        "reason": "비밀번호 인증엔 sshpass 가 필요합니다(미설치). 키 인증을 쓰거나 스크립트를 수동 실행하세요."}
            cmd = [sshpass, "-p", password]
        cmd += [ssh, "-p", str(ssh_port),
                "-o", "StrictHostKeyChecking=accept-new",
                "-o", "ConnectTimeout=10",
                "%s@%s" % (user, host), "bash -s"]
        try:
            p = subprocess.run(cmd, input=script.encode(),
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               timeout=600)
            out = p.stdout.decode("utf-8", "replace")[-4000:]
            return {"ok": (p.returncode == 0), "returncode": p.returncode, "output": out}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "reason": "SSH 실행 실패: %s" % e}

    def provision_ssh(self, raw: dict) -> dict:
        """[옵션] 원격에 SSH 로 접속해 구성 스크립트를 실행한다(키 또는 sshpass).

        무의존 원칙상 기본은 'A(스크립트 생성)'이며 이건 옵션이다.
        """
        plan = self.provision_plan(raw)
        if not plan.get("ok"):
            return plan
        return dict(plan, **self._ssh_run(raw, plan["script"]))

    # --- 원격 버전 업그레이드 ---
    def upgrade_plan(self, raw: dict) -> dict:
        """등록된 엣지(또는 host)를 HQ 최신 코드로 올리는 업그레이드 스크립트를 만든다.

        엣지에서 복붙 실행하면 HQ 포탈에서 최신 코드(agent-bundle)를 받아 코드 디렉터리에
        덮어쓰고 서비스를 재시작한다. 데이터(스캔 DB·설정)는 data-dir 라 영향받지 않는다.
        """
        nid = str(raw.get("id") or "").strip()
        edge_dir = (raw.get("edge_dir") or "/opt/isilon_edge").strip()
        service = (raw.get("service") or "isilon-edge").strip()
        hq_base = (raw.get("hq_base") or "").strip()
        script = build_upgrade_script(hq_base=hq_base, edge_dir=edge_dir, service=service)
        node_version = None
        if nid:
            with self._lock:
                node_version = (self._cache.get(nid) or {}).get("version")
        return {"ok": True, "script": script, "hq_version": __version__,
                "node_version": node_version, "edge_dir": edge_dir, "service": service}

    def upgrade_ssh(self, raw: dict) -> dict:
        """[옵션] SSH 로 엣지에 접속해 업그레이드 스크립트를 실행한다."""
        plan = self.upgrade_plan(raw)
        if not plan.get("ok"):
            return plan
        return dict(plan, **self._ssh_run(raw, plan["script"]))

    # --- 경로 비교(Cross-DC) — 복제본 DB 를 경로로 조인 ---
    @staticmethod
    def _to_local(node: dict, logical: str) -> str:
        """공통 논리 경로를 이 노드의 로컬 경로로 변환한다(별칭이 있으면).

        alias_logical 접두어를 alias_local 로 바꾼다. 별칭이 없으면 그대로(절대경로 일치).
        """
        al = (node.get("alias_local") or "").rstrip("/")
        lo = (node.get("alias_logical") or "").rstrip("/")
        if al and lo and (logical == lo or logical.startswith(lo + "/")):
            return al + logical[len(lo):]
        return logical

    def _replica_db_for(self, node_id: str, path: str):
        """노드 복제본에서 path 를 포함하는(root 가 prefix) 최신 완료 스캔 DB 경로."""
        rep = os.path.join(self.replicas_dir, node_id)
        try:
            with open(os.path.join(rep, "meta.json"), "r", encoding="utf-8") as fh:
                meta = json.load(fh)
        except (OSError, ValueError):
            return None
        best = None
        for s in meta.get("scans", []):
            root = (s.get("root_path") or "").rstrip("/")
            if path == root or path.startswith(root + "/"):
                if best is None or float(s.get("finished_at") or 0) > float(best.get("finished_at") or 0):
                    best = s
        if not best:
            return None
        dbf = best.get("db_filename") or os.path.basename(best.get("db_path") or "")
        dbp = os.path.join(rep, "scans", dbf)
        return dbp if (dbf and os.path.exists(dbp)) else None

    def compare_path(self, path: str) -> dict:
        """같은 경로의 노드별 용량/파일 수를 모아 비교한다(복제본 기준)."""
        path = os.path.abspath(path)
        rows = []
        for n in self.nodes:
            entry = {"id": n["id"], "region": n.get("region"), "found": False,
                     "total_bytes": 0, "own_bytes": 0, "total_files": 0, "subdir_count": 0}
            local = self._to_local(n, path)   # 논리 경로 → 이 노드의 로컬 경로(별칭)
            dbp = self._replica_db_for(n["id"], local)
            if dbp:
                try:
                    c = dbmod.connect(dbp)
                    rid = dbmod.latest_run_id(c)
                    r = c.execute(
                        "SELECT total_bytes, own_bytes, total_files, subdir_count "
                        "FROM directories WHERE run_id=? AND path=?", (rid, local)).fetchone()
                    c.close()
                    if r is not None:
                        sz = r["total_bytes"] if r["total_bytes"] else r["own_bytes"]
                        entry.update({"found": True, "total_bytes": sz,
                                      "own_bytes": r["own_bytes"], "total_files": r["total_files"],
                                      "subdir_count": r["subdir_count"]})
                except Exception:  # noqa: BLE001
                    pass
            rows.append(entry)
        return {"ok": True, "path": path, "rows": rows}

    def compare_matrix(self, path: str) -> dict:
        """path 직속 자식들의 노드별 용량 매트릭스(누락·드리프트 비교)."""
        path = os.path.abspath(path)
        node_ids = [n["id"] for n in self.nodes]
        children = {}
        for n in self.nodes:
            local = self._to_local(n, path)   # 논리 경로 → 이 노드의 로컬 경로(별칭)
            dbp = self._replica_db_for(n["id"], local)
            if not dbp:
                continue
            try:
                c = dbmod.connect(dbp)
                rid = dbmod.latest_run_id(c)
                prow = c.execute("SELECT depth FROM directories WHERE run_id=? AND path=?",
                                 (rid, local)).fetchone()
                if prow is None:
                    c.close()
                    continue
                like = (local.replace("\\", "\\\\").replace("%", "\\%")
                        .replace("_", "\\_")).rstrip("/") + "/%"
                kids = c.execute(
                    "SELECT name, total_bytes, own_bytes, subdir_count FROM directories "
                    "WHERE run_id=? AND depth=? AND path LIKE ? ESCAPE '\\'",
                    (rid, int(prow["depth"]) + 1, like)).fetchall()
                c.close()
                for k in kids:
                    e = children.setdefault(k["name"], {"name": k["name"], "subdir_count": 0, "vals": {}})
                    e["vals"][n["id"]] = int(k["total_bytes"] or k["own_bytes"] or 0)
                    e["subdir_count"] = max(e["subdir_count"], int(k["subdir_count"] or 0))
            except Exception:  # noqa: BLE001
                pass
        out = []
        for e in children.values():
            e["sum"] = sum(e["vals"].values())
            out.append(e)
        out.sort(key=lambda x: -x["sum"])
        return {"ok": True, "path": path, "nodes": node_ids, "children": out}


# ------------------------------------------------------------------ HTTP 핸들러
class PortalHandler(BaseHTTPRequestHandler):
    data_dir = ""
    controller = None  # PortalController

    def log_message(self, fmt, *args):  # noqa: D401 — 조용히
        pass

    def _send_json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except OSError:
            pass

    def _send_html(self, path: str) -> None:
        try:
            with open(path, "rb") as fh:
                body = fh.read()
        except OSError:
            self.send_error(404, "portal.html not found")
            return
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except OSError:
            pass

    def _read_json_body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", 0))
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, OSError):
            return {}

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            self._send_html(PORTAL_HTML)
            return
        c = self.controller
        try:
            if path == "/api/portal/auth":
                self._send_json(c.auth_status())
                return
            if path == "/api/portal/settings":
                self._send_json(c.upgrade_config())
                return
            if path == "/api/portal/upgrade/status":
                self._send_json(c.upgrade_status())
                return
            if path == "/api/portal/ping-history":
                qs = parse_qs(urlparse(self.path).query)
                try:
                    rng = int(qs.get("range", ["86400"])[0])
                except (TypeError, ValueError):
                    rng = 86400
                self._send_json(c.ping_history(rng))
                return
            if path == "/api/portal/browse":
                # HQ(포탈) 서버의 로컬 디렉터리 탐색 — 감시 폴더 등 경로 선택용.
                qp = parse_qs(urlparse(self.path).query).get("path", [""])[0]
                self._send_json(browse_dir(qp or "/"))
                return
            if path == "/api/portal/nodes":
                self._send_json(c.list_nodes())
                return
            if path == "/api/portal/overview":
                self._send_json(c.overview())
                return
            if path == "/api/portal/ping":
                self._send_json(c.ping_nodes())
                return
            if path == "/api/portal/agent-bundle":
                data = agent_bundle_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/gzip")
                self.send_header("Content-Disposition",
                                 'attachment; filename="isilon_usage_agent.tar.gz"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            if path == "/api/portal/compare":
                qp = parse_qs(urlparse(self.path).query).get("path", [""])[0]
                if not qp:
                    self._send_json({"ok": False, "reason": "path 필요"}, status=400)
                else:
                    self._send_json(c.compare_path(qp))
                return
            if path == "/api/portal/matrix":
                qp = parse_qs(urlparse(self.path).query).get("path", [""])[0]
                if not qp:
                    self._send_json({"ok": False, "reason": "path 필요"}, status=400)
                else:
                    self._send_json(c.compare_matrix(qp))
                return
            self._send_json({"ok": False, "reason": "unknown_endpoint"}, status=404)
        except ConnectionError:
            pass
        except Exception as exc:  # noqa: BLE001
            self._send_json({"ok": False, "error": str(exc)}, status=500)

    def _audit(self, action: str, ok: bool, detail: str = "") -> None:
        try:
            ip = self.client_address[0] if self.client_address else ""
        except Exception:  # noqa: BLE001
            ip = ""
        auditmod.record(self.data_dir, action=action, ok=ok, ip=ip, detail=detail)

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        body = self._read_json_body()
        c = self.controller
        try:
            if path == "/api/portal/login":
                res = c.login(body.get("password") or "")
                self._audit("login", res.get("ok"),
                            "" if res.get("ok") else (res.get("reason") or ""))
                self._send_json(res)
                return
            # 비밀번호 설정/변경/해제 — 이미 설정돼 있으면 로그인 필요(첫 설정은 허용)
            if path == "/api/portal/password":
                if c.auth_required() and not c.token_valid(self.headers.get("X-Op-Token")):
                    self._audit("password", False, "locked")
                    self._send_json({"ok": False, "reason": "locked", "op_required": True},
                                    status=401)
                    return
                res = c.set_password(body.get("password") or "", bool(body.get("encrypt")))
                self._audit("password", res.get("ok"))
                self._send_json(res)
                return
            # 그 외 변경 작업(노드 등록·삭제·동기화·원격 구성)은 로그인 필요
            if c.auth_required() and not c.token_valid(self.headers.get("X-Op-Token")):
                self._audit(path, False, "locked")
                self._send_json({"ok": False, "reason": "locked", "op_required": True,
                                 "error": "로그인 후 작업하세요."}, status=401)
                return
            if path == "/api/portal/audit":      # 감사 로그 조회(로그인 필요)
                self._send_json({"ok": True, "events": auditmod.tail(self.data_dir, 300)})
                return
            self._audit(path, True)              # 인증 통과한 변경 작업 기록
            if path == "/api/portal/settings":
                self._send_json(c.set_upgrade_watch(body.get("upgrade_watch_dir") or "",
                                                    body.get("upgrade_check_secs")))
                return
            if path == "/api/portal/upgrade/net":     # 인터넷 자동 업그레이드 설정
                self._send_json(c.set_upgrade_net(body.get("upgrade_source"),
                                                  body.get("upgrade_url"),
                                                  body.get("upgrade_auto"),
                                                  body.get("upgrade_check_secs")))
                return
            if path == "/api/portal/upgrade/check":   # 지금 인터넷에서 최신 확인
                self._send_json(c.upgrade_check())
                return
            if path == "/api/portal/upgrade/install":  # 지금 설치 + 엣지 전파 + 재시작
                self._send_json(c.upgrade_install(propagate=bool(body.get("propagate", True))))
                return
            if path == "/api/portal/upgrade-all":
                self._send_json(c.push_upgrade_all())
                return
            if path == "/api/portal/upgrade-all/ssh":
                self._send_json(c.push_upgrade_all_ssh(body))
                return
            if path == "/api/portal/nodes":
                self._send_json(c.upsert_node(body))
                return
            if path == "/api/portal/nodes/import":
                self._send_json(c.import_nodes_csv(body.get("csv") or ""))
                return
            if path == "/api/portal/nodes/delete":
                self._send_json(c.delete_node(str(body.get("id") or "")))
                return
            if path == "/api/portal/test":
                self._send_json(c.test_node(body))
                return
            if path == "/api/portal/sync":
                self._send_json(c.sync_now(body.get("id") or None))
                return
            if path == "/api/portal/node-scan":
                self._send_json(c.node_scan(str(body.get("id") or "")))
                return
            if path == "/api/portal/provision":
                self._send_json(c.provision_plan(body))
                return
            if path == "/api/portal/provision/ssh":
                self._send_json(c.provision_ssh(body))
                return
            if path == "/api/portal/upgrade":
                self._send_json(c.upgrade_plan(body))
                return
            if path == "/api/portal/upgrade/ssh":
                self._send_json(c.upgrade_ssh(body))
                return
            self._send_json({"ok": False, "reason": "unknown_endpoint"}, status=404)
        except ConnectionError:
            pass
        except Exception as exc:  # noqa: BLE001
            self._send_json({"ok": False, "error": str(exc)}, status=500)


def serve_portal(data_dir: str, host: str = "0.0.0.0", port: int = 8800):
    """글로벌 포탈 HTTP 서버를 만들어 반환한다(호출 측에서 serve_forever)."""
    data_dir = os.path.abspath(data_dir)
    mgrmod.migrate_legacy_config(data_dir)
    os.makedirs(data_dir, exist_ok=True)
    controller = PortalController(data_dir)
    controller.start()
    handler = type("BoundPortalHandler", (PortalHandler,),
                   {"data_dir": data_dir, "controller": controller})
    httpd = ThreadingHTTPServer((host, port), handler)
    httpd.controller = controller
    return httpd
