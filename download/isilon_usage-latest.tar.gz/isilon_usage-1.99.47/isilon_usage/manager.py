"""관리(매니저) DB — 여러 번의 스캔을 카탈로그로 묶어 전체 용량을 관리한다.

구조:
  <data-dir>/
    manager.db            ← 이 모듈이 다루는 관리 DB (모든 스캔의 요약 카탈로그)
    scans/
      scan_<시각>_<경로>.db   ← 실행마다 만들어지는 per-run DB(상세 데이터)

per-run DB 에는 그 스캔의 상세(디렉터리별 집계, 자원 시계열)가 들어가고,
manager.db 에는 각 스캔의 "요약 한 줄"이 들어가 전체를 한눈에 관리한다.
스캐너가 진행하면서 manager.db 의 해당 행을 주기적으로 갱신한다.
"""

from typing import Dict, Optional

import os
import re
import secrets
import shutil
import socket
import sys
import time

from . import db as dbmod


# 모든 영속 데이터/설정의 기본 위치 — 절대경로로 고정해 '실행 위치'나 '코드 업그레이드'
# 와 무관하게 항상 같은 곳에 저장한다(업그레이드 시 설정 유실 방지). --data-dir 로 변경 가능.
DEFAULT_DATA_DIR = "/data/isilon_usage"
MANAGER_DB_NAME = "manager.db"
SCANS_SUBDIR = "scans"

# 레거시(이전 기본/예시) data-dir — 기본 위치로 설정을 1회 이관해 업그레이드 보존.
LEGACY_DATA_DIRS = (
    "/var/lib/isilon_usage", "/var/lib/isilon_portal",
    "isilon_data", "isilon_portal_data",
)
# 이관 대상은 '설정'만(스캔/복제 DB 는 재생성 가능하므로 옮기지 않는다).
MIGRATE_CONFIG_FILES = ("settings.json", "portal_nodes.json")


MANAGER_SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    db_path         TEXT    NOT NULL,
    db_filename     TEXT    NOT NULL,
    root_path       TEXT    NOT NULL,
    hostname        TEXT,
    backend         TEXT,
    size_mode       TEXT,
    status          TEXT    NOT NULL DEFAULT 'discovering',
    phase           TEXT    NOT NULL DEFAULT 'discovering',
    started_at      REAL,
    updated_at      REAL,
    finished_at     REAL,
    discovered_dirs INTEGER NOT NULL DEFAULT 0,
    total_dirs      INTEGER NOT NULL DEFAULT 0,
    processed_dirs  INTEGER NOT NULL DEFAULT 0,
    total_files     INTEGER NOT NULL DEFAULT 0,
    error_dirs      INTEGER NOT NULL DEFAULT 0,
    scanned_bytes   INTEGER NOT NULL DEFAULT 0,
    fs_total_bytes  INTEGER NOT NULL DEFAULT 0,
    fs_used_bytes   INTEGER NOT NULL DEFAULT 0,
    fs_free_bytes   INTEGER NOT NULL DEFAULT 0,
    current_dir     TEXT,
    app_version     TEXT,
    note            TEXT,
    error           TEXT
);
CREATE INDEX IF NOT EXISTS idx_scans_root ON scans(root_path, id);
CREATE INDEX IF NOT EXISTS idx_scans_status ON scans(status);
"""


# ---------------------------------------------------------------- 경로 헬퍼

def manager_db_path(data_dir: str) -> str:
    return os.path.join(data_dir, MANAGER_DB_NAME)


def scans_dir(data_dir: str) -> str:
    return os.path.join(data_dir, SCANS_SUBDIR)


def migrate_legacy_config(data_dir: str) -> None:
    """업그레이드로 설정이 사라지지 않도록, 기본 data-dir 로 레거시 설정을 1회 복사한다.

    - 기본(canonical) data-dir 일 때만 동작한다(사용자가 직접 지정한 경로는 건드리지 않음).
    - 새 위치에 그 설정이 아직 없을 때만 레거시에서 복사한다(비파괴: 원본은 남긴다).
    - 베스트에포트 — 어떤 오류도 기동을 막지 않는다.
    """
    try:
        target = os.path.abspath(data_dir)
        if target != os.path.abspath(DEFAULT_DATA_DIR):
            return
        os.makedirs(target, exist_ok=True)
        for fname in MIGRATE_CONFIG_FILES:
            dst = os.path.join(target, fname)
            if os.path.exists(dst):
                continue
            for legacy in LEGACY_DATA_DIRS:
                src_dir = os.path.abspath(legacy)
                if src_dir == target:
                    continue
                src = os.path.join(src_dir, fname)
                if os.path.exists(src):
                    shutil.copy2(src, dst)
                    sys.stderr.write(
                        "[isilon_usage] 설정 이관(업그레이드 보존): %s -> %s\n" % (src, dst)
                    )
                    break
    except OSError:
        pass


def init_manager(data_dir: str) -> str:
    """data-dir 레이아웃과 manager.db 를 준비하고 manager.db 경로를 반환."""
    from . import SCHEMA_VERSION

    os.makedirs(scans_dir(data_dir), exist_ok=True)
    mpath = manager_db_path(data_dir)
    conn = dbmod.connect(mpath)
    try:
        conn.executescript(MANAGER_SCHEMA)
        dbmod.ensure_column(conn, "scans", "app_version", "TEXT")
        dbmod.ensure_column(conn, "scans", "partial_agg_at", "REAL")   # 멈춘 자료 부분 집계 시각
        # 시작 옵션(재개 때 그대로 복원 — 다르면 재개분이 다른 마운트로 넘어가거나 fold 깊이 체계가 어긋남)
        dbmod.ensure_column(conn, "scans", "opt_one_fs", "INTEGER")
        dbmod.ensure_column(conn, "scans", "opt_fold_depth", "INTEGER")
        dbmod.ensure_column(conn, "scans", "opt_max_depth", "INTEGER")
        # 멈춘 이유: 'orphan' = 실행 중 프로세스가 죽어 재기동 정리로 멈춤(예약 스캔은 이어서 재개)
        dbmod.ensure_column(conn, "scans", "paused_by", "TEXT")
        # 마운트 출처(포탈이 같은 파일시스템 식별 — 크기만 같은 다른 볼륨을 하나로 합치지 않게)
        dbmod.ensure_column(conn, "scans", "fs_source", "TEXT")
        conn.execute(f"PRAGMA user_version={int(SCHEMA_VERSION)}")
        conn.commit()
    finally:
        conn.close()
    return mpath


def make_run_db_path(data_dir: str, root_path: str) -> str:
    """루트 경로 + 현재 시각 + 고유 토큰으로 per-run DB 파일 경로를 생성.

    같은 루트를 같은 초에 두 번 시작해도 파일명이 충돌하지 않도록 짧은 난수
    토큰을 붙인다(충돌 시 두 스캔이 같은 DB 를 공유하는 문제 방지).
    """
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", root_path.strip("/")) or "root"
    base = base[-60:].strip("_") or "root"
    ts = time.strftime("%Y%m%d-%H%M%S")
    token = secrets.token_hex(3)
    return os.path.join(scans_dir(data_dir), f"scan_{ts}_{token}_{base}.db")


# ---------------------------------------------------------------- CRUD

def register_scan(
    data_dir: str,
    *,
    root_path: str,
    db_path: str,
    backend: str,
    size_mode: str,
) -> int:
    """새 스캔을 관리 DB 에 등록하고 manager 측 scan_id 를 반환."""
    from . import __version__

    conn = dbmod.connect(manager_db_path(data_dir))
    try:
        now = time.time()
        try:
            host = socket.gethostname()
        except Exception:
            host = None
        cur = conn.execute(
            """
            INSERT INTO scans
                (db_path, db_filename, root_path, hostname, backend, size_mode,
                 status, phase, started_at, updated_at, app_version)
            VALUES (?,?,?,?,?,?,'discovering','discovering',?,?,?)
            """,
            (os.path.abspath(db_path), os.path.basename(db_path), root_path,
             host, backend, size_mode, now, now, __version__),
        )
        conn.commit()
        return int(cur.lastrowid)
    finally:
        conn.close()


def update_scan(conn, scan_id: int, **fields) -> None:
    """관리 DB 의 스캔 요약 한 줄을 갱신(updated_at 자동)."""
    if not fields:
        return
    fields["updated_at"] = time.time()
    cols = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE scans SET {cols} WHERE id=?",
                 list(fields.values()) + [scan_id])


def get_scan(conn, scan_id: int):
    return conn.execute("SELECT * FROM scans WHERE id=?", (scan_id,)).fetchone()


def list_scans(conn, limit: int = 200) -> list:
    rows = conn.execute(
        "SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    return [dict(r) for r in rows]


def pick_default_scan(conn) -> Optional[int]:
    """대시보드 기본 표시 대상: 진행 중인 스캔 우선, 없으면 가장 최근."""
    row = conn.execute(
        "SELECT id FROM scans WHERE status IN ('discovering','sizing') "
        "ORDER BY id DESC LIMIT 1"
    ).fetchone()
    if row:
        return int(row["id"])
    row = conn.execute("SELECT id FROM scans ORDER BY id DESC LIMIT 1").fetchone()
    return int(row["id"]) if row else None


def scans_for_root(conn, root_path: str) -> list:
    """특정 루트의 모든 스캔(오래된→최신). 용량 추세 그래프용."""
    rows = conn.execute(
        "SELECT * FROM scans WHERE root_path=? ORDER BY id ASC", (root_path,)
    ).fetchall()
    return [dict(r) for r in rows]


def delete_scan(data_dir: str, scan_id: int) -> dict:
    """스캔의 per-run DB 파일과 관리 DB 행을 삭제한다."""
    conn = dbmod.connect(manager_db_path(data_dir))
    try:
        row = get_scan(conn, scan_id)
        if row is None:
            return {"ok": False, "reason": "없는 scan"}
        db_path = row["db_path"]
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(db_path + suffix)
            except OSError:
                pass
        conn.execute("DELETE FROM scans WHERE id=?", (scan_id,))
        conn.commit()
        return {"ok": True, "scan_id": scan_id}
    finally:
        conn.close()


def prune_scans(data_dir: str, *, keep_per_root: Optional[int] = None,
                older_than_days: Optional[float] = None,
                running_ids=None) -> dict:
    """오래된 스캔을 정리한다.

    keep_per_root: 루트별로 최신 N개만 남기고 나머지 삭제.
    older_than_days: 그보다 오래된(완료/오류) 스캔 삭제.
    실행 중(running_ids)인 스캔은 건너뛴다.
    """
    running = set(running_ids or [])
    conn = dbmod.connect(manager_db_path(data_dir))
    try:
        rows = conn.execute("SELECT * FROM scans ORDER BY id DESC").fetchall()
    finally:
        conn.close()

    # 루트별 '마지막 완료(done)' 스캔은 어떤 정리 규칙에서도 지우지 않는다 — 예전엔 id 순으로만 남겨,
    # 최근 스캔이 멈춤/오류면 마지막 정상 결과가 지워지고 부분 결과만 남았다.
    protected = set()
    _done_seen = set()
    for r in rows:
        if r["status"] == "done" and r["root_path"] not in _done_seen:
            _done_seen.add(r["root_path"])
            protected.add(r["id"])

    to_delete = set()
    if keep_per_root and keep_per_root > 0:
        seen: Dict[str, int] = {}
        for r in rows:
            rp = r["root_path"]
            seen[rp] = seen.get(rp, 0) + 1
            if seen[rp] > keep_per_root:
                to_delete.add(r["id"])
    if older_than_days and older_than_days > 0:
        cutoff = time.time() - older_than_days * 86400
        for r in rows:
            ts = r["finished_at"] or r["started_at"] or 0
            if ts and ts < cutoff and r["status"] in ("done", "error", "paused"):
                to_delete.add(r["id"])

    deleted = []
    for sid in sorted(to_delete - protected):
        if sid in running:
            continue
        if delete_scan(data_dir, sid).get("ok"):
            deleted.append(sid)
    return {"ok": True, "deleted": deleted, "count": len(deleted)}


def estimate_eta_seconds(phase, processed, total_dirs, discovered, elapsed):
    """남은 시간(초) 추정 — 집계(sizing) 단계에서만: 지금까지의 처리 속도로 남은 디렉터리를 나눈다.

    대시보드 '요약'·홈 카드·포탈이 모두 이 함수 하나를 쓴다(단일 소스). 폴더 찾기(discovering) 단계는
    전체 디렉터리 수를 아직 모르므로 None. 경과(elapsed)는 스캔 시작부터라 탐색 시간이 포함돼,
    추정은 보수적(실제보다 길게)으로 나온다."""
    try:
        processed = int(processed or 0)
        elapsed = float(elapsed or 0)
        total = int(total_dirs or 0) or int(discovered or 0)
    except (TypeError, ValueError):
        return None
    if phase != "sizing" or processed <= 0 or elapsed <= 0:
        return None
    rate = processed / elapsed
    return max(total - processed, 0) / rate if rate > 0 else None


def overall_capacity(conn) -> dict:
    """전체 용량 관리 집계.

    같은 루트를 여러 번 스캔했을 수 있으므로 루트별로 한 번만 센다. 루트마다 두 가지를 준다:
      - 활동(status·phase·진행 카운터·scanned_bytes·시각) = 그 루트의 '가장 최근' 스캔 — 진행 중 표시·처리량용
      - 용량(capacity_*) = 그 루트의 '마지막 완료(done)' 스캔 — 완료 스캔이 없으면 최신 스캔 값(capacity_partial)
    예전엔 최신 스캔을 상태와 무관하게 용량으로 써서, 멈춤·오류·진행 중인 부분 결과(예: 7바이트)가 그 루트의
    용량으로 표시·합산됐다. total_capacity_bytes = 용량 합(화면·포탈의 '조사 용량'), total_scanned_bytes = 최신
    스캔 합(진행량 — 처리량 시계열이 쓰므로 의미를 바꾸지 않는다).
    """
    scans = conn.execute("SELECT * FROM scans ORDER BY id DESC").fetchall()
    latest_by_root: Dict[str, dict] = {}
    done_by_root: Dict[str, dict] = {}
    for s in scans:
        rp = s["root_path"]
        if rp not in latest_by_root:  # id 내림차순이므로 처음 본 게 최신
            latest_by_root[rp] = dict(s)
        if rp not in done_by_root and s["status"] == "done":
            done_by_root[rp] = dict(s)

    roots = []
    total_scanned = 0
    total_capacity = 0
    now_ts = time.time()
    for rp, s in latest_by_root.items():
        cap = done_by_root.get(rp) or s
        cap_bytes = int(cap.get("scanned_bytes") or 0)
        eta = (estimate_eta_seconds(s.get("phase"), s.get("processed_dirs"), s.get("total_dirs"),
                                    s.get("discovered_dirs"), now_ts - float(s.get("started_at") or now_ts))
               if s["status"] in ("discovering", "sizing") else None)
        total_scanned += s.get("scanned_bytes") or 0
        total_capacity += cap_bytes
        roots.append({
            "scan_id": s["id"],
            "root_path": rp,
            "hostname": s.get("hostname"),
            "status": s["status"],
            "phase": s["phase"],
            "scanned_bytes": s.get("scanned_bytes") or 0,
            "total_dirs": s.get("total_dirs") or 0,
            "discovered_dirs": s.get("discovered_dirs") or 0,
            "processed_dirs": s.get("processed_dirs") or 0,
            "total_files": s.get("total_files") or 0,
            "fs_total_bytes": s.get("fs_total_bytes") or 0,
            "fs_used_bytes": s.get("fs_used_bytes") or 0,
            "fs_free_bytes": s.get("fs_free_bytes") or 0,
            "fs_source": s.get("fs_source") or cap.get("fs_source"),
            "started_at": s.get("started_at"),
            "finished_at": s.get("finished_at"),
            "updated_at": s.get("updated_at"),
            "partial_agg_at": s.get("partial_agg_at"),   # 멈춘 자료 부분 집계 시각(이력 표 배지)
            "capacity_bytes": cap_bytes,
            "capacity_files": int(cap.get("total_files") or 0),
            "capacity_scan_id": cap["id"],
            "capacity_finished_at": cap.get("finished_at") if cap.get("status") == "done" else None,
            "capacity_partial": rp not in done_by_root,     # 완료 스캔이 아직 없어 부분 값
            # 진행 중이면 남은 시간(초)과 끝날 시각(epoch) 추정 — 상태 화면 '요약'과 같은 계산
            "eta_seconds": eta,
            "eta_at": (now_ts + eta) if eta is not None else None,
        })
    roots.sort(key=lambda x: x["capacity_bytes"], reverse=True)

    active = sum(1 for s in scans if s["status"] in ("discovering", "sizing"))
    return {
        "total_scanned_bytes": total_scanned,
        "total_capacity_bytes": total_capacity,
        "root_count": len(latest_by_root),
        "scan_count": len(scans),
        "active_scans": active,
        "roots": roots,
    }
